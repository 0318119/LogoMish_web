import React from 'react'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
import OurWork from '../../components/OurWork/work'

const ourwork = () => {
  return (
    <div>
      {/* <Header/> */}
        <OurWork/>
      {/* <Footer/> */}
    </div>
  )
}

export default ourwork
