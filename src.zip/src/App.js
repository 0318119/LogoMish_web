import React from 'react';
import './App.css';
import '../src/assets/css/main.css'
import Home from './pages/Home/Home';

function App() {
  return (
     <div>
        <Home />
     </div>
  );
}

export default App