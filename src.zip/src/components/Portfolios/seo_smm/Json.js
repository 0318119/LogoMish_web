
import one from   '../assets/images/seo_smm/1.avi'
import two from   '../assets/images/seo_smm/2.avi'
import three from '../assets/images/seo_smm/3.avi'
import four from  '../assets/images/seo_smm/4.avi'
import five from  '../assets/images/seo_smm/5.avi'
import six from   '../assets/images/seo_smm/6.avi'
import seven from '../assets/images/seo_smm/7.avi'
import eight from '../assets/images/seo_smm/8.avi'

export const photos = [
    {
        src: one,
        width: 4,
        height: 3,
    },
    {
        src: two,
        width: 4,
        height: 3,
    },
    {
        src: three,
        width: 4,
        height: 3,
    },
    {
        src: four,
        width: 4,
        height: 3,
    },
    {
        src: five,
        width: 4,
        height: 3,
    },
    {
        src: six,
        width: 4,
        height: 3,
    },
    {
        src: seven,
        width: 4,
        height: 3,
    },
    {
        src: eight,
        width: 4,
        height: 3,
    }
];