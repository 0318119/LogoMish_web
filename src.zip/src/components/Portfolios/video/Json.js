
import one from   '../assets/images/videos/one.gif'
import two from   '../assets/images/videos/two.gif'
import three from '../assets/images/videos/3.gif'
import four from  '../assets/images/videos/4.gif'
import five from  '../assets/images/videos/5.gif'
import six from   '../assets/images/videos/6.gif'
import seven from '../assets/images/videos/7.gif'
import eight from '../assets/images/videos/8.gif'
import nine from  '../assets/images/videos/9.gif'

export const photos = [
    {
        src: one,
        width: 4,
        height: 3,
    },
    {
        src: two,
        width: 4,
        height: 3,
    },
    {
        src: three,
        width: 4,
        height: 3,
    },
    {
        src: four,
        width: 4,
        height: 3,
    },
    {
        src: five,
        width: 4,
        height: 3,
    },
    {
        src: six,
        width: 4,
        height: 3,
    },
    {
        src: seven,
        width: 4,
        height: 3,
    },
    {
        src: eight,
        width: 4,
        height: 3,
    },
    {
        src: nine,
        width: 4,
        height: 3,
    }
];