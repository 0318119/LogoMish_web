
import one from   '../assets/images/BUSINESS/1.avi'
import two from   '../assets/images/BUSINESS/2.avi'
import three from '../assets/images/BUSINESS/3.avi'
import four from  '../assets/images/BUSINESS/4.avi'
import five from  '../assets/images/BUSINESS/5.avi'
import six from   '../assets/images/BUSINESS/6.avi'
import seven from '../assets/images/BUSINESS/7.avi'
import eight from '../assets/images/BUSINESS/8.avi'
import nine from  '../assets/images/BUSINESS/9.avi'

export const photos = [
    {
        src: one,
        width: 4,
        height: 3,
    },
    {
        src: two,
        width: 4,
        height: 3,
    },
    {
        src: three,
        width: 4,
        height: 3,
    },
    {
        src: four,
        width: 4,
        height: 3,
    },
    {
        src: five,
        width: 4,
        height: 3,
    },
    {
        src: six,
        width: 4,
        height: 3,
    },
    {
        src: seven,
        width: 4,
        height: 3,
    },
    {
        src: eight,
        width: 4,
        height: 3,
    },
    {
        src: nine,
        width: 4,
        height: 3,
    }
];